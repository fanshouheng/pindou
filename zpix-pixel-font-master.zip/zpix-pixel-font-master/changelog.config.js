// https://github.com/streamich/git-cz

module.exports = {
  disableEmoji: true,
  maxMessageLength: 64,
  minMessageLength: 3,
};
